package com.example.wifiapp

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.nio.charset.StandardCharsets
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var bluetoothAdapter: BluetoothAdapter
    private lateinit var bluetoothLeAdvertiser: BluetoothLeAdvertiser
    private lateinit var bluetoothLeScanner: BluetoothLeScanner
    private lateinit var chatDisplay: TextView
    private lateinit var messageInput: EditText
    private lateinit var sendButton: Button
    private lateinit var nameInput: EditText
    private lateinit var saveNameButton: Button

    private val handler = Handler(Looper.getMainLooper())
    private val PERMISSION_REQUEST_CODE = 1001
    private val BLUETOOTH_REQUEST_CODE = 1002

    private val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB") // Custom UUID
    private val recentMessages = mutableSetOf<String>() // Track recent messages
    private var userName: String = "You" // Default name

    private var scanCallback: ScanCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        chatDisplay = findViewById(R.id.chatDisplay)
        messageInput = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)
        nameInput = findViewById(R.id.nameInput)
        saveNameButton = findViewById(R.id.saveNameButton)

        // Initialize BluetoothAdapter
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Check and request permissions
        if (checkPermissions()) {
            initializeBluetooth()
        } else {
            requestPermissions()
        }

        // Set up button click listeners
        sendButton.setOnClickListener { sendMessage() }
        saveNameButton.setOnClickListener { saveUserName() }
    }

    private fun saveUserName() {
        val name = nameInput.text.toString().trim()
        if (name.isNotEmpty()) {
            userName = name
            Toast.makeText(this, "Name saved: $userName", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Please enter a valid name", Toast.LENGTH_SHORT).show()
        }
    }

    private fun initializeBluetooth() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            if (!bluetoothAdapter.isEnabled) {
                // Start the Bluetooth enable request
                val enableBluetoothIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivityForResult(enableBluetoothIntent, BLUETOOTH_REQUEST_CODE)
            } else {
                startBluetoothLe()
            }
        } else {
            // Request BLUETOOTH_CONNECT permission
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun startBluetoothLe() {
        bluetoothLeAdvertiser = bluetoothAdapter.bluetoothLeAdvertiser
        bluetoothLeScanner = bluetoothAdapter.bluetoothLeScanner
        startScanning()
    }

    private fun startScanning() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            scanCallback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    super.onScanResult(callbackType, result)
                    val scanRecord = result.scanRecord
                    if (scanRecord != null) {
                        val serviceData = scanRecord.getServiceData(ParcelUuid(uuid))
                        if (serviceData != null) {
                            try {
                                val message = String(serviceData, StandardCharsets.UTF_8)
                                handler.post {
                                    if (!recentMessages.contains(message)) {
                                        recentMessages.add(message)
                                        chatDisplay.append("\n$message") // Display the full message
                                    }
                                }
                            } catch (e: Exception) {
                                // Ignore invalid messages
                            }
                        }
                    }
                }
            }

            // Add scan filter
            val filter = ScanFilter.Builder()
                .setServiceUuid(ParcelUuid(uuid))
                .build()

            bluetoothLeScanner.startScan(
                listOf(filter),
                ScanSettings.Builder().build(),
                scanCallback!!
            )
        }
    }

    private fun sendMessage() {
        val message = messageInput.text.toString()
        if (message.isNotEmpty()) {
            if (message.length > 30) { // Updated to 30 characters
                Toast.makeText(this, "Message too long", Toast.LENGTH_SHORT).show()
                return
            }

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_ADVERTISE
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                // Include the user's name in the message
                val fullMessage = "$userName: $message"

                // Stop any existing advertising
                bluetoothLeAdvertiser.stopAdvertising(advertiseCallback)

                // Start new advertising
                val advertiseData = AdvertiseData.Builder()
                    .addServiceUuid(ParcelUuid(uuid))
                    .addServiceData(ParcelUuid(uuid), fullMessage.toByteArray(StandardCharsets.UTF_8))
                    .build()

                val advertiseSettings = AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                    .setConnectable(false)
                    .build()

                bluetoothLeAdvertiser.startAdvertising(advertiseSettings, advertiseData, advertiseCallback)
                handler.post { chatDisplay.append("\n$fullMessage") }
                messageInput.text.clear()
            } else {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.BLUETOOTH_ADVERTISE),
                    PERMISSION_REQUEST_CODE
                )
                Toast.makeText(this, "Advertise permission required", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            Toast.makeText(this@MainActivity, "Message broadcasted", Toast.LENGTH_SHORT).show()
        }

        override fun onStartFailure(errorCode: Int) {
            Toast.makeText(this@MainActivity, "Failed to broadcast message", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkPermissions(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.ACCESS_FINE_LOCATION
            ),
            PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                initializeBluetooth()
            } else {
                Toast.makeText(this, "Permissions denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == BLUETOOTH_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                startBluetoothLe()
            } else {
                Toast.makeText(this, "Bluetooth must be enabled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scanCallback?.let {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) {
                bluetoothLeScanner.stopScan(it)
            }
        }
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_ADVERTISE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            bluetoothLeAdvertiser.stopAdvertising(advertiseCallback)
        }
    }
}